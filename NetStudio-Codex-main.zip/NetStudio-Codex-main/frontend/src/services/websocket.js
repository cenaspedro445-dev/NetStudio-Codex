let ws = null
let reconnectAttempts = 0
const MAX_RECONNECT = 5

export const initWebSocket = () => {
  if (ws) return ws

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const url = `${protocol}//${window.location.host}/ws/chat`

  ws = new WebSocket(url)

  ws.onopen = () => {
    console.log('WebSocket connected')
    reconnectAttempts = 0
  }

  ws.onerror = (err) => {
    console.error('WebSocket error:', err)
  }

  ws.onclose = () => {
    ws = null
    if (reconnectAttempts < MAX_RECONNECT) {
      reconnectAttempts++
      setTimeout(() => initWebSocket(), 3000 * reconnectAttempts)
    }
  }

  return ws
}

export const sendMessage = (data) => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data))
  }
}
