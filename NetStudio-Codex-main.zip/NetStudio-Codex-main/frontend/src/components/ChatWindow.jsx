import { useEffect, useRef, useState } from 'react'
import { useStore } from '../store'
import { Send } from 'lucide-react'
import Message from './Message'

function ChatWindow() {
  const { messages, loading, addMessage, updateLastMessage, currentConversation } = useStore()
  const [input, setInput] = useState('')
  const messagesEndRef = useRef(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSend = async () => {
    if (!input.trim() || !currentConversation) return

    const userMessage = { id: Date.now(), role: 'user', content: input }
    addMessage(userMessage)
    setInput(''))

    addMessage({ id: Date.now() + 1, role: 'assistant', content: '' })

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation_id: currentConversation,
          message: input
        })
      })

      const reader = response.body.getReader()
      const decoder = new TextDecoder()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value)
        updateLastMessage((prev) => prev + chunk)
      }
    } catch (err) {
      console.error('Chat error:', err)
      updateLastMessage('Error: ' + err.message)
    }
  }

  return (
    <div className="flex-1 flex flex-col bg-dark">
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">NetStudio Codex</h2>
              <p>Start a conversation with Qwen</p>
            </div>
          </div>
        ) : (
          messages.map((msg) => <Message key={msg.id} message={msg} />)
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-6 border-t border-gray-700">
        <div className="flex gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Message Qwen..."
            className="flex-1 bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-accent"
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="bg-accent text-white rounded-lg px-4 py-3 hover:bg-opacity-90 disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  )
}

export default ChatWindow
