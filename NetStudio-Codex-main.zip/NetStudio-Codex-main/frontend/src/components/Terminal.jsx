import { useState, useEffect } from 'react'

function Terminal() {
  const [logs, setLogs] = useState([])

  useEffect(() => {
    const ws = new WebSocket('ws://localhost:8000/ws/logs')
    ws.onmessage = (event) => {
      const log = JSON.parse(event.data)
      setLogs((prev) => [...prev, log])
    }
    return () => ws.close()
  }, [])

  return (
    <div className="h-48 bg-darker border-t border-gray-700 p-4 overflow-y-auto font-mono text-sm text-gray-300">
      {logs.map((log, i) => (
        <div key={i} className={log.level === 'error' ? 'text-red-400' : 'text-green-400'}>
          [{log.timestamp}] {log.message}
        </div>
      ))}
    </div>
  )
}

export default Terminal
