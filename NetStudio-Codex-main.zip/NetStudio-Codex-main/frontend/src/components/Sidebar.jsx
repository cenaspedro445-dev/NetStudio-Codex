import { useState } from 'react'
import { Plus, MessageSquare, Trash2, Settings } from 'lucide-react'
import { useStore } from '../store'

function Sidebar() {
  const { conversations, currentConversation, setCurrentConversation } = useStore()

  const handleNewChat = () => {
    const id = `conv-${Date.now()}`
    setCurrentConversation(id)
  }

  return (
    <div className="w-64 bg-darker border-r border-gray-700 flex flex-col">
      <button
        onClick={handleNewChat}
        className="m-4 p-3 bg-accent text-white rounded-lg hover:bg-opacity-90 flex items-center justify-center gap-2 font-semibold"
      >
        <Plus size={20} /> New Chat
      </button>

      <div className="flex-1 overflow-y-auto px-4 space-y-2">
        {conversations.map((conv) => (
          <div
            key={conv.id}
            onClick={() => setCurrentConversation(conv.id)}
            className={`p-3 rounded-lg cursor-pointer flex items-center justify-between group ${
              currentConversation === conv.id
                ? 'bg-gray-700'
                : 'hover:bg-gray-800'
            }`}
          >
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <MessageSquare size={16} />
              <span className="text-sm truncate">{conv.title || 'New Chat'}</span>
            </div>
            <Trash2 size={16} className="opacity-0 group-hover:opacity-100" />
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-gray-700">
        <button className="w-full p-2 rounded-lg hover:bg-gray-800 flex items-center justify-center gap-2 text-sm">
          <Settings size={16} /> Settings
        </button>
      </div>
    </div>
  )
}

export default Sidebar
