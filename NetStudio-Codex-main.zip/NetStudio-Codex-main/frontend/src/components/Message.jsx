import ReactMarkdown from 'react-markdown'
import SyntaxHighlighter from 'react-syntax-highlighter'
import { atomOneDark } from 'react-syntax-highlighter/dist/esm/styles/hljs'

function Message({ message }) {
  const isUser = message.role === 'user'

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-xl px-4 py-3 rounded-lg ${
          isUser
            ? 'bg-accent text-white'
            : 'bg-gray-700 text-gray-100'
        }`}
      >
        <ReactMarkdown
          components={{
            code({ inline, className, children }) {
              const lang = className?.replace('language-', '') || 'javascript'
              return inline ? (
                <code className="bg-gray-900 px-1 rounded">{children}</code>
              ) : (
                <SyntaxHighlighter
                  style={atomOneDark}
                  language={lang}
                  className="rounded my-2"
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              )
            },
            p: ({ children }) => <p className="mb-2">{children}</p>,
            ul: ({ children }) => <ul className="list-disc list-inside mb-2 ml-2">{children}</ul>,
            ol: ({ children }) => <ol className="list-decimal list-inside mb-2 ml-2">{children}</ol>
          }}
        >
          {message.content}
        </ReactMarkdown>
      </div>
    </div>
  )
}

export default Message
