import { create } from 'zustand'

export const useStore = create((set) => ({
  conversations: [],
  currentConversation: null,
  messages: [],
  loading: false,
  modelStatus: { online: false, model: 'qwen3' },
  tasks: [],
  
  setConversations: (conversations) => set({ conversations }),
  setCurrentConversation: (id) => set({ currentConversation: id }),
  setMessages: (messages) => set({ messages }),
  setLoading: (loading) => set({ loading }),
  setModelStatus: (status) => set({ modelStatus: status }),
  setTasks: (tasks) => set({ tasks }),
  
  addMessage: (message) => set((state) => ({
    messages: [...state.messages, message]
  })),
  
  updateLastMessage: (content) => set((state) => ({
    messages: state.messages.map((m, i) => 
      i === state.messages.length - 1 ? { ...m, content } : m
    )
  }))
}))
