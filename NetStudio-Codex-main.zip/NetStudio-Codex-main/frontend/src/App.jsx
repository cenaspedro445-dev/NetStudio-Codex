import { useState, useEffect } from 'react'
import Sidebar from './components/Sidebar'
import ChatWindow from './components/ChatWindow'
import Terminal from './components/Terminal'
import { useStore } from './store'
import { initWebSocket } from './services/websocket'

function App() {
  const [showTerminal, setShowTerminal] = useState(false)
  const { setModelStatus } = useStore()

  useEffect(() => {
    checkModelStatus()
    const ws = initWebSocket()
    
    return () => {
      if (ws) ws.close()
    }
  }, [])

  const checkModelStatus = async () => {
    try {
      const res = await fetch('/api/health')
      const data = await res.json()
      setModelStatus({ online: data.ollama_online, model: data.model })
    } catch (err) {
      setModelStatus({ online: false, model: 'qwen3' })
    }
  }

  return (
    <div className="flex h-screen bg-dark">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <ChatWindow />
        {showTerminal && <Terminal />}
        <button
          onClick={() => setShowTerminal(!showTerminal)}
          className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white text-sm"
        >
          {showTerminal ? 'Hide Terminal' : 'Show Terminal'}
        </button>
      </div>
    </div>
  )
}

export default App
