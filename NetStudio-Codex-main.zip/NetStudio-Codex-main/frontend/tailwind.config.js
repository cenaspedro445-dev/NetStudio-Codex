export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        dark: '#0d0d0d',
        darker: '#050505',
        accent: '#10a37f'
      }
    }
  },
  plugins: []
}
