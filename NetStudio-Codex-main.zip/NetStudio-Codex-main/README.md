# NetStudio-Codex
Arquitetura modular para agentes de IA, memória, ferramentas e automação.
